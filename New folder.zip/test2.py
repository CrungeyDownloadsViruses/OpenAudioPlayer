import base64
import io
import os
import json
import shutil
import subprocess
import time
from flask import Flask, request, jsonify
from pydub import AudioSegment

# Initialize Flask app
app = Flask(__name__)

# Define route for vocal separation
@app.route('/separate', methods=['POST'])
def separate_vocals():
    try:
        # Get JSON data from request body
        data = request.json

        print(json.dumps(data)[0:100])  # Print truncated data
        print("ok")

        # Decode the base64 audio file location
        fileLoc = str(base64.b64decode(data["audio"]))
        fileLoc = fileLoc.split("b'", 1)[1]
        fileLoc = fileLoc[0:len(fileLoc) - 1]
        fileLoc = fileLoc.replace("&amp;", "&")
        fileLoc = fileLoc.split("<div style=")[0]
        print("`" + fileLoc + "`")

        # Load the audio file and convert it to WAV format
        audio = AudioSegment.from_file("audio/" + fileLoc, frame_rate=44100, channels=2, sample_width=2)
        output_path = "input.wav"
        audio.export(output_path, format="wav").close()
        print("Formatted and exported to input.wav")

        # Check if the file exists to confirm export completion
        if os.path.exists(output_path):
            print("Export complete. Proceeding with Demucs separation...")

        # Use Demucs with a 2-source model and specify GPU usage
        demucs_command = ["demucs", "-n", "mdx_extra_q", "-d", "cuda", output_path]
        result = subprocess.run(demucs_command, capture_output=True, text=True)

        # Log Demucs output for debugging
        print("Demucs output:", result.stdout)
        print("Demucs errors:", result.stderr)

        # Wait a moment for the process to finish and files to be created
        time.sleep(2)
        print("moving files")
        os.rename("separated/mdx_extra_q/input/vocals.wav", "separated/mdx_extra_q/input/" + fileLoc + "_vocals.wav")
        os.rename("separated/mdx_extra_q/input/other.wav", "separated/mdx_extra_q/input/" + fileLoc + "_other.wav")
        os.rename("separated/mdx_extra_q/input/bass.wav", "separated/mdx_extra_q/input/" + fileLoc + "_bass.wav")
        os.rename("separated/mdx_extra_q/input/drums.wav", "separated/mdx_extra_q/input/" + fileLoc + "_drums.wav")
        def move_files(source_dir, dest_dir):
    
            
            for filename in os.listdir(source_dir):
                 source_path = os.path.join(source_dir, filename)
                 dest_path = os.path.join(dest_dir, filename)

                # Check if it's a file (not a directory)
                 if os.path.isfile(source_path):
                     os.rename(source_path, dest_path)

        if __name__ == "__main__":
             source_dir = "separated/mdx_extra_q/input/"
             dest_dir = "audio/"
             move_files(source_dir, dest_dir)
        # Check if the files exist after running Demucs
        demucs_output_dir = os.path.join("separated", "mdx_extra_q", "input")
        vocals_path = os.path.join(demucs_output_dir, "vocals.wav")
        instrumental_path = os.path.join(demucs_output_dir, "no_vocals.wav")

        if not os.path.exists(vocals_path) or not os.path.exists(instrumental_path):
            return jsonify({"error": "Separation failed. Files not found."}), 500

        # Load separated files from Demucs output directory
        vocals = AudioSegment.from_file(vocals_path)
        instrumental = AudioSegment.from_file(instrumental_path)

        # Prepare the original filename without extension
        original_filename = os.path.splitext(fileLoc.split("/")[-1])[0]

        # Define the output directory
        output_directory = r"C:\Users\AJ\radio\audio"

        # Rename and move files to the output directory
        def rename_and_move_files(original_filename):
            # Create new file names and move them
            for stem in [("vocals.wav", "other.wav"), ("drums.wav", "bass.wav")]:
                stem_path = os.path.join(demucs_output_dir, stem[0])
                if os.path.isfile(stem_path):
                    new_filename = f"{original_filename}{stem[1]}"
                    new_file_path = os.path.join(output_directory, new_filename)
                    shutil.move(stem_path, new_file_path)

        rename_and_move_files(original_filename)

        # Clean up temporary files
        os.remove("input.wav")
        shutil.rmtree(demucs_output_dir)
        shutil.rmtree(os.path.join("separated", "mdx_extra_q"))

        # Return confirmation
        return jsonify({"done"})

    except Exception as e:
        print("Error:", str(e))  # Print the error for debugging
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=3020)
