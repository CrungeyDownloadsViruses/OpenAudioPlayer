const express = require('express');
require('audio-context');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
holder = "";
const app = express();
const port = 3010;
const ytdlp = require('ytdlp-nodejs');
const ytdl = require('yt-get');
app.use(express.text());
app.use(express.json({limit: '500mb'}));
var bodyParser = require('body-parser');
app.use(bodyParser.json({limit: '500mb'}) );
const os = require('os');
app.use(bodyParser.urlencoded({
  limit: '500mb',
  extended: true,
  parameterLimit:50000
}));
const audioDir = path.join(__dirname, 'audio');
var randomFile = "";
let lastYtTitle = "";
// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));
app.post('/downloadAudio', async (req, res) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).send('YouTube URL is required');
  }

  try {
    const { exec } = require('child_process');
    exec(`yt-dlp --extract-audio --audio-format mp3 --output "./audio/%(title)s.%(ext)s" ` + url, (err, stdout, stderr) => {
    if (err) {
      // node couldn't execute the command
      return;
    }

    // the *entire* stdout and stderr (buffered)
    console.log(`stdout: ${stdout}`);
    console.log(`stderr: ${stderr}`);
    console.log("complete");
    });
    

    
    res.send(`complete`);
  } catch (error) {
    console.error('Error downloading video:', error);
    res.status(500).send('An error occurred while downloading the audio.');
  }
});








// Usage example




// Endpoint to fetch a random audio file
app.get('/getAudioAtIndex', (req, res) => {
  const newData = parseInt(req.query.index); // Get the index from query parameters

  fs.readdir(audioDir, (err, files) => {
      if (err) {
          return res.status(500).send('Unable to scan directory');
      }

      const audioFiles = files.filter(file => file.endsWith('.mp3') || file.endsWith('.wav') || file.endsWith('.mp4'));
      if (audioFiles.length === 0) {
          return res.status(404).send('No audio files found');
      }

      if (newData < 0 || newData >= audioFiles.length) {
          return res.status(400).send('Invalid index');
      }
      console.log(audioFiles[newData]);
      const holder = path.join(audioDir, audioFiles[newData]);
      console.log(holder);
      res.sendFile(holder);
  });
});

app.get('/getAudioNames', (req, res) => {
  //const newData = parseInt(req.query.index);  Get the index from query parameters

  fs.readdir(audioDir, (err, files) => {
      if (err) {
          return res.status(500).send('Unable to scan directory');
      }

      const audioFiles = files.filter(file => file.endsWith('.mp3') || file.endsWith('.wav') || file.endsWith('.mp4'));
      if (audioFiles.length === 0) {
          return res.status(404).send('No audio files found');
      }

      
      //console.log(audioFiles[newData]);
      //const holder = path.join(audioDir, audioFiles[newData]);
      //console.log(holder);
      let allAudio = "";
      for(let name of audioFiles)
      {
        allAudio = allAudio + name.toString() + "|||||";
      }
      res.send(allAudio);
  });
});

app.get('/getAudioNameAtIndex', (req, res) => {
  const newData = parseInt(req.query.index); // Get the index from query parameters

  fs.readdir(audioDir, (err, files) => {
      if (err) {
          return res.status(500).send('Unable to scan directory');
      }

      const audioFiles = files.filter(file => file.endsWith('.mp3') || file.endsWith('.wav') || file.endsWith('.mp4'));
      if (audioFiles.length === 0) {
          return res.status(404).send('No audio files found');
      }

      if (newData < 0 || newData >= audioFiles.length) {
          return res.status(400).send('Invalid index');
      }

      const holder = path.join(audioDir, audioFiles[newData]);
      console.log(audioFiles[newData]);
      res.send(audioFiles[newData].toString());
  });
});

app.get('/audioListLength', (req, res) => {
  fs.readdir(audioDir, (err, files) => {
    if (err) {
      return res.status(500).send('Unable to scan directory');
    }


    const audioFiles = files.filter(file => file.endsWith('.mp3') || file.endsWith('.wav') || file.endsWith('.mp4'));
    if (audioFiles.length === 0) {
      return res.status(404).send('No audio files found');
    }
	

    res.send(audioFiles.length.toString());
  });
});



app.get('/radio', (req, res) => {
res.sendFile(path.join(__dirname, 'index.html'));
});
app.get('/beatdetect.js', (req, res) => {
  res.sendFile(path.join(__dirname, '/BeatDetect/src/BeatDetect.js'));
  });
app.get('/currentsong', (req, res) => {
res.sendFile(holder);
});

app.post('/separate', async (req, res) => {
  try {
      // Extract base64 audio data from the request body
      const inputBase64 = req.body;
      console.log(inputBase64);
      // Send POST request to Python server
      const response = await axios.post('http://localhost:3020/separate', inputBase64, {
          headers: { 'Content-Type': 'application/json' },
          audio: inputBase64.audio,
          body: inputBase64
      });

      // Send back the response from the Python server
      res.send(response.data);

  } catch (error) {
      console.error('Error communicating with Python server:', );
      res.status(500).send('An error occurred while processing the audio.');
  }
});





app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
